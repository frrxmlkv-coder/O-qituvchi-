package uz.oqituvchi.hisobi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import org.json.JSONArray
import org.json.JSONObject

data class Student(val id: Long, val name: String, val phone: String, val fee: Long, val paid: Long)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("teacher_account", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var students by remember { mutableStateOf(loadStudents()) }
            var showAdd by remember { mutableStateOf(false) }
            var payFor by remember { mutableStateOf<Student?>(null) }
            fun save(list: List<Student>) {
                students = list
                val arr = JSONArray()
                list.forEach { s -> arr.put(JSONObject().put("id",s.id).put("name",s.name).put("phone",s.phone).put("fee",s.fee).put("paid",s.paid)) }
                prefs.edit().putString("students", arr.toString()).apply()
            }
            val totalFee = students.sumOf { it.fee }
            val totalPaid = students.sumOf { it.paid }
            MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF176B87))) {
                Scaffold(topBar = { TopAppBarCompat() { showAdd = true } }) { pad ->
                    Column(Modifier.padding(pad).padding(16.dp)) {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text("UMUMIY HISOB", fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("O‘quvchilar: ${students.size}")
                                Text("Belgilangan oylik: ${money(totalFee)} so‘m")
                                Text("Jami to‘langan: ${money(totalPaid)} so‘m")
                                Text("Qolgan qarzdorlik: ${money((totalFee-totalPaid).coerceAtLeast(0))} so‘m")
                                Text("Oldindan to‘lov: ${money((totalPaid-totalFee).coerceAtLeast(0))} so‘m")
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Text("O‘QUVCHILAR", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        if (students.isEmpty()) Text("Hozircha o‘quvchi yo‘q. “+ O‘quvchi” tugmasini bosing.")
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(students, key = { it.id }) { s ->
                                val balance = s.fee - s.paid
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(s.name, fontWeight = FontWeight.Bold)
                                        if (s.phone.isNotBlank()) Text(s.phone)
                                        Text("Oylik to‘lov: ${money(s.fee)} so‘m")
                                        Text(if (balance > 0) "Qarzdor: ${money(balance)} so‘m" else if (balance < 0) "Oldindan: ${money(-balance)} so‘m" else "To‘liq to‘langan")
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(onClick = { payFor = s }) { Text("To‘lov kiritish") }
                                            OutlinedButton(onClick = { save(students.filterNot { it.id == s.id }) }) { Text("O‘chirish") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (showAdd) AddStudentDialog(onDismiss={showAdd=false}, onSave={ name, phone, fee ->
                    save(students + Student(System.currentTimeMillis(),name,phone,fee,0)); showAdd=false
                })
                payFor?.let { s -> PaymentDialog(s, onDismiss={payFor=null}, onSave={amount ->
                    save(students.map { if (it.id==s.id) it.copy(paid=it.paid+amount) else it }); payFor=null
                }) }
            }
        }
    }
    private fun loadStudents(): List<Student> = try {
        val arr = JSONArray(prefs.getString("students","[]"))
        (0 until arr.length()).map { i -> val o=arr.getJSONObject(i); Student(o.getLong("id"),o.getString("name"),o.optString("phone"),o.getLong("fee"),o.getLong("paid")) }
    } catch (_: Exception) { emptyList() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun TopAppBarCompat(onAdd: () -> Unit) {
    TopAppBar(title={ Text("O‘QITUVCHI HISOBI", fontWeight=FontWeight.Bold) },
        actions={ TextButton(onClick=onAdd) { Text("+ O‘quvchi") } })
}
fun money(v: Long) = "%,d".format(v).replace(',', ' ')

@Composable fun AddStudentDialog(onDismiss:()->Unit, onSave:(String,String,Long)->Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var fee by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss, title={Text("Yangi o‘quvchi")},
        text={ Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name,{name=it},label={Text("Ism-familiya")}, singleLine=true)
            OutlinedTextField(phone,{phone=it},label={Text("Telefon (ixtiyoriy)")}, singleLine=true)
            OutlinedTextField(fee,{fee=it.filter(Char::isDigit)},label={Text("Oylik to‘lov (so‘m)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
        }},
        confirmButton={ Button(enabled=name.isNotBlank() && fee.toLongOrNull()!=null,onClick={onSave(name.trim(),phone.trim(),fee.toLong())}) { Text("Saqlash") } },
        dismissButton={ TextButton(onClick=onDismiss){Text("Bekor qilish")} })
}
@Composable fun PaymentDialog(student:Student,onDismiss:()->Unit,onSave:(Long)->Unit) {
    var amount by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text("${student.name} — to‘lov")},
        text={OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("To‘langan summa (so‘m)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)},
        confirmButton={Button(enabled=amount.toLongOrNull()?.let{it>0}==true,onClick={onSave(amount.toLong())}){Text("Kiritish")} },
        dismissButton={TextButton(onClick=onDismiss){Text("Bekor qilish")}})
}
