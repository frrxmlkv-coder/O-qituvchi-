O‘QITUVCHI HISOBI — Android Studio loyiha boshlang‘ich versiyasi

Talablar:
- Android Studio (Giraffe yoki yangiroq)
- JDK 17
- Internet (Gradle kutubxonalarini birinchi marta yuklash uchun)

Ishga tushirish:
1. ZIP faylni oching.
2. Android Studio -> Open -> Oqituvchi_Hisobi papkasini tanlang.
3. Gradle Sync tugashini kuting.
4. Telefonni USB debugging orqali ulang yoki emulator tanlang.
5. Run tugmasini bosing.
6. APK uchun Build -> Build Bundle(s) / APK(s) -> Build APK(s).

Hozirgi prototip:
- O‘quvchi qo‘shish (har biriga alohida oylik narx)
- Telefon raqami
- To‘lov kiritish
- Qarzdorlik / ortiqcha to‘lovni hisoblash
- Jami ko‘rsatkichlar
- Ma’lumotlar telefonda saqlanadi (offline)

Eslatma: Bu birinchi ishlaydigan prototip. Oylar bo‘yicha alohida hisob, oldindan to‘lovni keyingi oyga avtomatik o‘tkazish, tranzaksiyalar tarixi, tahrirlash, PDF/Excel va zaxira nusxa keyingi bosqichda qo‘shiladi. APK bu ZIP ichida tayyor kompilyatsiya qilingan emas; Android Studio orqali build qilinadi.
